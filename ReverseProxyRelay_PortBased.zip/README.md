# ReverseProxyRelay (Port-Based Routing)

This .NET 8 app runs on a staging server and proxies requests to specific middle-tier services **based on port number**.

## 🔧 Features

- Supports all HTTP methods
- Routes to target middle-tier using the port number
- Uses proxy only for configured targets

---

## 🧪 Example Usage

Call from any application with just protocol, host, and port:

```http
http://staging-server:5001/api/data  → MiddleTierA (via proxy)
http://staging-server:5002/api/data  → MiddleTierB (no proxy)
```

---

## 🔨 Setup

### 1. Build & Run

```bash
dotnet build
dotnet run
```

Or publish:

```bash
dotnet publish -c Release -o out
cd out
dotnet ReverseProxyRelay.dll
```

### 2. Expose Ports

Ensure ports `5001`, `5002` are open in firewall / reverse proxy.

---

## ⚙️ Configuration

Edit `appsettings.json`:

```json
{
  "Proxy": {
    "Url": "http://your-proxy-url:port",
    "Username": "proxy-user",
    "Password": "proxy-password"
  },
  "ProxyTargets": ["MiddleTierA"],
  "ProxyMap": {
    "MiddleTierA": "https://middle-tier-a.com",
    "MiddleTierB": "https://middle-tier-b.com"
  }
}
```

---

## 🛡️ Security

For production or internet-exposed servers, consider:
- Binding to localhost and using SSH tunnel
- Adding authentication
- Using HTTPS via NGINX/Apache reverse proxy

---

## 📁 Folder Structure

```
ReverseProxyRelay/
├── Program.cs
├── ProxyHandler.cs
├── appsettings.json
├── ReverseProxyRelay.csproj
└── README.md
```